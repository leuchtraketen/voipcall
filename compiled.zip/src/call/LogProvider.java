package call;

public interface LogProvider {
	String getLog();
}