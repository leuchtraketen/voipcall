package call;

public enum ConnectionState {
	CONNECTING, OPEN, CLOSED
}
