package call;

public class NoAudioDeviceException extends UnknownDefaultValueException {

	public NoAudioDeviceException(String text) {
		super(text);
	}

	private static final long serialVersionUID = -686952558116330549L;

}
