/**
 * Translated from the C code of Skype SILK codec (ver. 1.0.6) Downloaded from
 * http://developer.skype.com/silk/
 * 
 * Class "Config" is mainly based on the pre-compile configurations from the C
 * source code
 */
package codec.silk.impl;

/**
 * 
 * @author Jing Dai
 */
public class Config {
	static boolean _SYSTEM_IS_BIG_ENDIAN = true;

	static final boolean SKP_USE_DOUBLE_PRECISION_FLOATS = false;
}
