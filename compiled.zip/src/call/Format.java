package call;

import javax.sound.sampled.AudioFormat;

public interface Format extends Id {

	AudioFormat getAudioFormat();

}
