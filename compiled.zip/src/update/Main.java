package update;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Enumeration;
import java.util.zip.ZipEntry;
import java.util.zip.ZipException;
import java.util.zip.ZipFile;

public class Main {
	public static void main(String[] args) {

	}

	static public void extractFolder(File zipfile, File extractpath) throws ZipException, IOException {
		System.out.println("unzip: " + zipfile);
		int BUFFER = 2048;

		ZipFile zip = new ZipFile(zipfile);

		extractpath.mkdirs();
		Enumeration<? extends ZipEntry> zipFileEntries = zip.entries();

		// Process each entry
		while (zipFileEntries.hasMoreElements()) {
			// grab a zip file entry
			ZipEntry entry = (ZipEntry) zipFileEntries.nextElement();
			String currentEntry = entry.getName();
			File destFile = new File(extractpath, currentEntry);
			// destFile = new File(newPath, destFile.getName());
			destFile.getParentFile().mkdirs();

			if (!entry.isDirectory()) {
				BufferedInputStream is = new BufferedInputStream(zip.getInputStream(entry));
				int currentByte;
				// establish buffer for writing file
				byte data[] = new byte[BUFFER];

				System.out.println("extract: " + destFile);
				// write the current file to disk
				FileOutputStream fos = new FileOutputStream(destFile);
				BufferedOutputStream dest = new BufferedOutputStream(fos, BUFFER);

				// read and write until last byte is encountered
				while ((currentByte = is.read(data, 0, BUFFER)) != -1) {
					dest.write(data, 0, currentByte);
				}
				dest.flush();
				dest.close();
				is.close();
			
			} else {
				destFile.mkdirs();
			}
			
			if (currentEntry.endsWith(".zip")) {
				// found a zip file, try to open
				try {
					extractFolder(destFile, destFile.getParentFile());
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}

		zip.close();
	}
}
