package call;

import java.io.OutputStream;

public interface Capture {
	OutputStream getCaptureOutputStream();
}
