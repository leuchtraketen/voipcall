package call;

public interface Id {
	String getId();
}
