package call;

public interface Id extends Comparable<Id> {
	String getId();
}
