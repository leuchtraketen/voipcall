package call;

public interface AudioDeviceUpdateListener extends Id {

	void onAudioDeviceUpdate();

}
