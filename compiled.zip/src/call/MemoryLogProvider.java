package call;

public class MemoryLogProvider implements LogProvider {

	@Override
	public String getLog() {
		return null;
	}

}
