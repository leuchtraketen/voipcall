package call;

public class UnknownDefaultValueException extends Exception {

	public UnknownDefaultValueException(String text) {
		super(text);
	}

	private static final long serialVersionUID = -3335733823668734720L;

}
