package call;

public interface Activatable {
	boolean isActive();
	void close();
}
